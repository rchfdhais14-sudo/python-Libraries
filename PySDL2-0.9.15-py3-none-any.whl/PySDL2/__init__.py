__version__ = "0.9.15"
def info():
    return "PySDL2 mobile graphics system ready."